package com.srm.dto.risco;

public interface RiscoStrategy {
	Double calcularJuros(Double limite);
}
