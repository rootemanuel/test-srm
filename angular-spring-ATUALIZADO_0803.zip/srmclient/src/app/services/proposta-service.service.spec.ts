import { TestBed, inject } from '@angular/core/testing';

import { PropostaServiceService } from './proposta-service.service';

describe('PropostaServiceService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [PropostaServiceService]
    });
  });

  it('should be created', inject([PropostaServiceService], (service: PropostaServiceService) => {
    expect(service).toBeTruthy();
  }));
});
