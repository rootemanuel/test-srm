package com.srm.dao;

import com.srm.entity.PropostaEntity;

public interface PropostaDao {
	void insereProposta(PropostaEntity proposta);
}
