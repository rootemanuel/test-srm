import { Component, OnInit } from '@angular/core';
import { PropostaServiceService } from './services/proposta-service.service';

class Proposta {
  private nomeCliente: String;
  private limiteCredito: String;
  private risco: Number;
}

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent implements OnInit {
  private proposta: Proposta;
  private req: string = null;
  private msg: string = null;

  title = 'SRM - FRONTEND';

  constructor(private _service: PropostaServiceService) { }

  ngOnInit(): void {
    this.proposta = new Proposta();
  }

  incluir(): void {

    this.req = JSON.stringify(this.proposta);
    this._service.save(this.req)
      .toPromise().then(rtn => {
        let jrtn = JSON.stringify(rtn.json());
        this.msg = `Criado com sucesso ${jrtn}`;
      })
      .catch(ex => {
        let jex = JSON.parse(ex._body);
        this.msg = jex.msg;
      });;
  }
}
