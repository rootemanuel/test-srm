import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Http } from '@angular/http';
import 'rxjs/add/operator/toPromise';


@Injectable()
export class PropostaServiceService {

  constructor(private _http: Http) { }

  save(proposta: string): Observable<any> {
    return this._http.
      post('http://127.0.0.1:8080/proposta', JSON.parse(proposta));
  }
}
