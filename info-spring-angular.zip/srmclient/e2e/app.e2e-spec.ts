import { LOL4YOUPage } from './app.po';

describe('lol4-you App', () => {
  let page: LOL4YOUPage;

  beforeEach(() => {
    page = new LOL4YOUPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
